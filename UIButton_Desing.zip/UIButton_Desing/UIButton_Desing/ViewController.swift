//
//  ViewController.swift
//  UIButton_Desing
//
//  Created by kobayashi on 2022/03/30.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        button.setTitle("明日はおはようございます！明日はおはようございます！明日はおはようございます！明日はおはようございます！", for: .normal)
        //        button.titleLabel?.lineBreakMode = .byTruncatingTail
//        button.titleLabel?.lineBreakMode = .byClipping
//        button.titleLabel?.lineBreakMode = .byWordWrapping
//        button.titleLabel?.lineBreakMode = .byCharWrapping
//        button.titleLabel?.lineBreakMode = .byTruncatingHead
//        button.titleLabel?.lineBreakMode = .byTruncatingMiddle
//        button.contentVerticalAlignment = .fill
//        button.titleLabel?.adjustsFontSizeToFitWidth = false
        button.titleLabel?.numberOfLines = 1
//        button.line lineBreakMode = .byClipping
        
    }


}

